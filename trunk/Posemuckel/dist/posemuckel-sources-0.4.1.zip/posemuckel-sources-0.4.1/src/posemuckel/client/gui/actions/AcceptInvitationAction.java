/**
 * 
 */
package posemuckel.client.gui.actions;

import org.eclipse.swt.widgets.Table;

/**
 * 
 * @author Posemuckel Team
 *
 */

public class AcceptInvitationAction extends JoinProjectAction {

	public AcceptInvitationAction(Table projects) {
		super(projects, "ACCEPT_INVITATION");		
	}


}
