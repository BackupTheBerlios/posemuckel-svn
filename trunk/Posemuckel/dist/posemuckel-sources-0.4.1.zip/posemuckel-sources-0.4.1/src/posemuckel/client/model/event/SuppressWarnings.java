/**
 * 
 */
package posemuckel.client.model.event;

/**
 * Hebt die Wirkung der @SuppressWarnings wieder auf, da dieser Dummy zwar das
 * gleiche Interface, aber nicht die gleiche Funktionalit�t hat.
 * @author Posemuckel Team
 *
 */

public @interface SuppressWarnings {
	
	String value();

}
