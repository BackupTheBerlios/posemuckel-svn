/**
 * 
 */
package posemuckel.client.model.event;

/**
 * 
 * @author Tanja Buttler
 *
 */
public class ChatAdapter implements ChatListener {

	/* (non-Javadoc)
	 * @see posemuckel.client.model.event.ChatListener#typing(posemuckel.client.model.event.ChatEvent)
	 */
	public void typing(ChatEvent event) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see posemuckel.client.model.event.ChatListener#reading(posemuckel.client.model.event.ChatEvent)
	 */
	public void reading(ChatEvent event) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see posemuckel.client.model.event.ChatListener#chatting(posemuckel.client.model.event.ChatEvent)
	 */
	public void chatting(ChatEvent event) {
		// TODO Auto-generated method stub

	}

}
