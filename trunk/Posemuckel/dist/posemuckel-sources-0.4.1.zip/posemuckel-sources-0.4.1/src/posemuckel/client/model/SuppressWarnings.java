/**
 * 
 */
package posemuckel.client.model;

/**
 * 
 * @author Posemuckel Team
 *
 */

public @interface SuppressWarnings {
	
	String value();

}
