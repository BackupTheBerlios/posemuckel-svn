The license given in the file LICENSE.txt does not apply to
files and directories with a separate license file.